﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IdentityModel.Selectors;

namespace WcfService1
{
    public class CustomUserNameValidator: UserNamePasswordValidator
    {
        public override void Validate(string userName, string password)
        {
            if((null==password) ||(null==password ))
                throw new ArgumentNullException();
            if (!(userName == "armando" && password=="ciao" ) )
            {
                throw new Exception("CAZZONE, NON SAJ AAA PASSWORD...ALANIMADELIMORTACCITUA");
            }

           
        }
    }
}