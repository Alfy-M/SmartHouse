﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    /*
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "data/{temp}/{hum}/{gas}", 
                   BodyStyle = WebMessageBodyStyle.Wrapped, 
                   ResponseFormat = WebMessageFormat.Json)]
       string JSONData(string temp,string hum,string gas);//,string hum,string gas);
      
    }
    
    */

    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        [WebInvoke(Method = "POST",
                    RequestFormat = WebMessageFormat.Xml,
                    ResponseFormat = WebMessageFormat.Xml,
                    UriTemplate = "sendData",
                   BodyStyle = WebMessageBodyStyle.Bare
                   )]
        ResponseData SendData(RequestData rData);

        [OperationContract]
        [WebInvoke(Method = "POST",
                    RequestFormat = WebMessageFormat.Xml,
                    ResponseFormat = WebMessageFormat.Xml,
                    UriTemplate = "getData",
                   BodyStyle = WebMessageBodyStyle.Bare
                   )]
        ResponseDataPeriod GetData(RequestData rData);
    }

    [DataContract(Namespace = "http://www.cosacosacosa.com/cosa")]
    public class RequestData
    {
        [DataMember]
        public string details { get; set; }

    }
    [DataContract]
    public class ResponseData
    {
        [DataMember]
        public string s { get; set; }


    }

    [DataContract]
    public class ResponseDataPeriod
    {
        [DataMember]
        public string s { get; set; }


    }
    // Use a data contract as illustrated in the sample below to add composite types to service operations.

}
