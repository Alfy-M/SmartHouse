﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace WcfService1
{
    //Prompt dei comandi: 
    //netsh http add urlacl url=http://+:51417/ user=\everyone
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        #region IService1 Members
        string Pass;
        string Dat;
        string Temp;
        string Hum;
        string Gas;
        string Period;
        string s1;
        public ResponseData SendData(RequestData rData)
        {
            //Debug.Print("arrivata");
            //Debug.Print(rData.ToString());
            var data = rData.details.Split('|');


            Pass = data[0];
            Dat = data[1];

            Temp = fromDot(data[2]);
            Hum = fromDot(data[3]);
            Gas = fromDot(data[4]);

            Debug.Print("RICEZIONE:" + " " + Pass + " " + Dat + " " + Temp + " " + Hum + " " + Gas);
            if (validatePass())
                s1 = "wrong password";
            else
                s1 = insertInDatabase();

            var response = new ResponseData
            {
                s = s1
            };


            return response;

        }
        public ResponseDataPeriod GetData(RequestData rData)
        {
            var data = rData.details.Split('|');


            Pass = data[0];
            Period = data[1];

            if (validatePass())
                s1 = "wrong password";
            else
                s1 = selectInDatabase(Period);

            var response = new ResponseDataPeriod
            {
                s = s1
            };
            return response;
        }
        #endregion
        private string insertInDatabase()
        {
            DateTime dt = DateTime.Parse(Dat);
            try
            {
                DataSet1TableAdapters.valueTableAdapter valueTA = new DataSet1TableAdapters.valueTableAdapter();
                valueTA.Insert(dt, float.Parse(Temp), float.Parse(Hum), float.Parse(Gas));
            }
            catch (Exception)
            {
                return "no";
            }

            return "ok";
        }

        private string selectInDatabase(string period)
        {
             double a,b,c;
           
            try
            {
                DataSet1TableAdapters.valueTableAdapter valueTA = new DataSet1TableAdapters.valueTableAdapter();
                //string vec = valueTA.GetDataBy().ToString();
                //DataSet1.valueDataTable dta = 
                if (period.Equals("today"))
                {
                    a = valueTA.tempDay().Value;
                    b = valueTA.humDay().Value;
                    c = valueTA.gasDay().Value;
                }
                else if (period.Equals("week"))
                {
                    //query del mese
                    a = valueTA.tempWeek().Value;
                    b = valueTA.humWeek().Value;
                    c = valueTA.gasWeek().Value;
                }
                else if (period.Equals("month"))
                {
                    a = valueTA.tempMonth().Value;
                    b = valueTA.humMonth().Value;
                    c = valueTA.gasMonth().Value;
                }
                else return "|wrong period value|";
               /* foreach (DataRow row in dta.Rows)
                {
                    foreach (DataColumn col in dta.Columns)
                    {
                        queryResult += row[col].ToString().Trim() + "|";
                    }
                }*/

                //  Debug.Print(dta.temperatureColumn.ToString());

                //Debug.Print(valueTA.GetDataBy().Rows.
                //                    .temperatureColumn.);


            }
            catch (Exception)
            {
                return "no";
            }
            
            return "|"+a.ToString("F2")+"|"+b.ToString("F2")+"|"+c.ToString("F2")+"|";
        }
        private bool validatePass()
        {
            return !(Pass.Equals("armando"));
        }
        private string fromDot(string str)
        {
            string floa;
            var temp = str.Split('.');
            floa = temp[0] + "," + temp[1];
            return floa;
        }
    }

}
