﻿namespace WcfService1 {
    
    
    public partial class DataSet1 {
    }
}
